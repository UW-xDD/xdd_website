# Data Engineer — Programming Test (Code Review)

We have written a simple script to count occurrences of words in a file. It seems to work correctly, but we want you to review and improve the script. It may contain several kinds of coding problems, including bugs, security flaws, performance problems, unclear code, and so on.

The initial script is available in four different languages, within the `./problem1` directory. **Choose only one:**

-   Python
-   Perl
-   Ruby
-   Java

Please code review the script, list the problems you find, and try to fix them. Thus, your answer must contain two parts:

1.  A list of problems that you find in the code. Briefly describe each one, in a sentence or two.
2.  A new version of the complete script, in which you have fixed all of the problems that you found; feel free to change the script as much as you need to.

## Notes

How the script is _supposed_ to work:

-   The script expects two command-line arguments: the name of an input file and a threshold (an integer). Here is an example of how to run the script (assuming that it is named `problem1-executable`):
    ``` bash
    problem1-executable problem1-input.txt 50
    ```
-   The input file contains exactly one word per line, with no whitespace before or after the word. The script **does not** need to verify the contents of the input file.
-   The letter case of words in the input file does not matter for counting. For example, the script should count “the”, “The”, and “THE” as the same word.
-   After counting the words, the script prints a report (to standard output) that lists the words and their counts. Each word is printed only if its count is greater than or equal to the threshold given on the command line. Words are printed in alphabetic order.

## Input File

The input file is included in the `problem1` directory and is named `problem1-input.txt`. Keep in mind that this is just one data file, and that your program should work correctly on all files in the format described above.

This sample contains 10,000 words total. With this input file, a good threshold to use is about 50, which will result in a reasonable amount of output, about 25 lines.

