# Data Engineer — Programming Test (Data Transform)

We have provided a [bibjson](http://okfnlabs.org/bibjson/) file containing bibliographical information for a small number of scientific publications in JSON format. We'd like to ingest this data, eventually storing it into a relational database. As a first step toward this process, we'd like to create a general bibjson-to-CSV parser. 

Please create an initial version of this transformer. Specifically, write a piece of software in your language of choice which:
- Opens and reads a bibjson file (an example is provided)
- Parses the data and writes it to a CSV file

## Notes

Be sure to include documentation with sufficient instructions for installing and running your code. Providing a link to a Docker image to ease portability is fine, but if you choose to do this, be sure to include the source code in your provided solution! This documentation should also clarify any assumptions you made.

## Input File

The input file is included in the `problem2` directory and is named `xdd_sample.bibjson`. Again, keep in mind that this is just one sample file, and that your program should be flexible enough to work on any file of this format.