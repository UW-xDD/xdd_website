# Data Engineer — Programming Tests

There are two program exercises to complete for this assessment. They are designed to be relatively easy tests of basic programming skills, but include some of the skills that are relevant to this position.

Send your solutions in a single email back to htcondor-jobs@cs.wisc.edu

The following guidelines apply equally to all three parts:

- Write each solution in a programming language that you know and that seems appropriate to the problem; you may use the same or different languages for the problems. The position will most likely use Python, Java/Javascript, and shell scripting, maybe with a few others now and then. **However,** you do not need to use one of these languages, and we are pretty good at figuring out and running programs in other ones. Show us what you are good at!
- Make sure that your solutions can be run on a typical, modern Unix or Linux system. You may develop your solutions on another platform (e.g., Windows), but avoid code that prevents the program from running elsewhere. Probably, we will run your code on a Red Hat Enterprise Linux 7-compatible system.
- If the problem description seems vague or incomplete, make reasonable assumptions and state them clearly along with your solution (either in-code comments or separate text are fine).
- In terms of programming priorities, we prefer clarity first, then correctness, and efficiency last. This implies, for instance, that your programs should be reasonably efficient but not at the expense of being straightforward and clear.
- Pretend that you are writing the programs for your own use and for colleagues. Thus, each program should provide useful feedback when it detects basic errors, but you do not need to write extensive error testing, write documentation, or provide tests.
- For each part, turn in your complete and working program, sample output (using our input files), and any other supporting comments.

Have fun with the challenges! We look forward to receiving your solutions and will continue processing your application when we do.