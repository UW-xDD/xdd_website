# Programming Test (Data Conversion)

We have provided a [bibjson](http://okfnlabs.org/bibjson/) file containing bibliographical information for a small number of scientific publications in JSON format. We'd like to ingest this data, eventually storing it into a relational database. As a first step toward this process, we'd like to create a general bibjson-to-CSV converter. 

Please create an initial version of this transformer. Specifically, write a piece of software in your language of choice which:
 
- Opens and reads a bibjson file (an example is provided)
- Parses the data and writes it to a CSV file

Your answer should include:
 
1. The source code of your converter
2. Documentation (either within the code or in a separate file) outlining any decisions or assumptions you made. For example, you will need to make certain decisions about how to handle some of the data fields (see the "Input File" section below). Provide a brief explanation of these decisions.
3. Sufficient instructions for installing and running your code. Providing a link to a Docker image to ease portability is fine, but if you do this, be sure to include the code as well.

## Notes

- Feel free to use any library/module you believe would be useful. There's no need to re-invent the wheel! For example, if you're using python, the `json` and `csv` modules within the standard library are highly recommended.

## Input File

- The input file is included in the `problem2` directory and is named `xdd_sample.bibjson`. Again, keep in mind that this is just one sample file, and that your program should be flexible enough to work on any file of this format. 
- You will face formatting decisions and potentially some inconsistencies. As an example, the "author" field is an array of objects within the bibjson file (and can be empty!). How you choose to represent this data within the output CSV is up to you, but be sure to include an explanation of these key decisions.

