#!/usr/bin/perl

($filename, $threshold) = @ARGV;

# Validate arguments
if ($threhsold =~ /^\D+$/) {
    print "The threshold must be a number.\n";
    exit 1;
}

# Read file and tally word frequencies.
# Original case of word does not matter: "the" = "The" = "THE"
open $fh, $filename;
my @words;
while (my $line = <$fh>) {
    chomp($line);
    my $found = 0;
    foreach $word_ref (@words) {
        if ($word_ref->[0] eq lc($line)) {
            $found = 1;
            $word_ref->[1]++;
        }
    }

    # initialize a new word with a frequency of 1
    if (not $found) {
        push(@words, [$line, 1]);
    }
}

# Print words and their frequencies, sorted alphabetically by word.  Only
# print a word if its frequency is greater than or equal to the threshold.
foreach $word_ref (sort {$a->[0] cmp $b->[0]} @words) {
    next if $word_ref->[1] < $threshold;
    printf "%4d %s\n", $word_ref->[1], $word_ref->[0];
}
