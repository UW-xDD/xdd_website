#!/usr/bin/ruby

filename, threshold = ARGV[0..1]

# Validate arguments
if threshold =~ /^\D+$/
   puts 'The threshold must be a number.'
   exit(1)
end

# Read file and tally word frequencies.
# Original case of word does not matter: "the" = "The" = "THE"
words = []
IO.foreach(filename) do |line|
  line.strip
  found = false
  words.each do |word|
    if word[0] == line.downcase
      found = true
      word[1] += 1
    end
  end

  # initialize a new word with a frequency of 1
  if not found
    words << [line, 1]
  end
end

# Print words and their frequencies, sorted alphabetically by word.  Only
# print a word if its frequency is greater than or equal to the threshold.
words.sort.each do |word|
   next if word[0] < threshold
   printf "%4d %s", word[1], word[0]
end
